#!/bin/bash -l
#SBATCH -C gpu
#SBATCH -q regular
#SBATCH -t 00:15:00
#SBATCH -J LAMMPS_SNAP
#SBATCH -o LAMMPS_SNAP.o%j
#SBATCH -A nstaff
#SBATCH -N _NODES_
#SBATCH --ntasks-per-node=4
#SBATCH -c 32
#SBATCH --gpus-per-task=1
#SBATCH --gpu-bind=none
#SBATCH --gpus-per-node=4

# Path where lammps-modules are stored
ml use /global/cfs/cdirs/nstaff/rgayatri/modules/
ml use PrgEnv-gnu

# Which MPI-flavour
#mpi="cray-mpich"
#mpi="mpich"
#mpi="open-mpi"

mpi=_MPI_

# Load the needed MPI-flavour
if [ $mpi == "mpich" ]; then
    ml load mpich/4.1.1
elif [ $mpi == "open-mpi" ]; then
    ml load openmpi/5.0.0rc12
    OPENMPI_FLAGS="--mpi=pmix"
fi

# Load the MPI-flavour
ml load lammps/Jun152023-$mpi

exe="lmp-$mpi"

# Create dir to store output
make_dir="results/$mpi/N${SLURM_NNODES}"
if [ ! -d ${make_dir} ]; then
    mkdir -p ${make_dir}
    cp ${0} ${make_dir}
fi

gpus_per_node=${SLURM_NTASKS_PER_NODE}

# LAMMPS x,y,z and time-steps
nx=80
ny=80
nz=80
ts=1000

input="-k on g ${gpus_per_node} -sf kk -pk kokkos gpu/aware on comm host newton on neigh half -in in.snap.test -var nsteps $ts -var nx $nx -var ny $ny -var nz $nz -var snapdir 2J14_W.SNAP/"

command="srun -n $SLURM_NTASKS ${OPENMPI_FLAGS} $exe $input"

echo $command

$command

# wait for the job to finish
wait

# copy the output to directory that makes sense
#cp log.lammps ${make_dir}
cp LAMMPS_SNAP.o$SLURM_JOB_ID ${make_dir}
