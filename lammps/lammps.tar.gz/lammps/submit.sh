#!/bin/bash

mpi_impl="open-mpi"
#mpi_impl="cray-mpich mpich open-mpi"

for mpi in ${mpi_impl}
do
    for nnodes in 32 #16 32 64 128
    do
        echo $mpi
        sed 's/_NODES_/'$(( $nnodes ))'/g' run-lammps.sh> tmp.sub.$mpi.$nnodes
        sed -i 's/_MPI_/'$mpi'/g' tmp.sub.$mpi.$nnodes
        sbatch tmp.sub.$mpi.$nnodes
    done
done
