#!/bin/bash

# load modules
ml load cmake
ml load PrgEnv-gnu/8.3.3
ml load mpich/4.1.1
ml unload cray-libsci/23.02.1.1

# necessary to use CUDA-Aware MPI and run a job
export CRAY_ACCEL_TARGET=nvidia80

# optimize CUDA compilation for A100
export AMREX_CUDA_ARCH=8.0

export CXXFLAGS="-march=znver3"
export CFLAGS="-march=znver3"

# compiler environment hints
export CC=mpicc
export CXX=mpic++
export FC=mpifort
export CUDACXX=$(which nvcc)
export CUDAHOSTCXX=$CXX

cmake -S . -B upstream_mpich -DWarpX_COMPUTE=CUDA
cmake --build upstream_mpich -j 16
