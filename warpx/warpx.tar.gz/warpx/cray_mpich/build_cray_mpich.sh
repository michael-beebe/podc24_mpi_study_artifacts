#!/bin/bash

# load modules
ml load cmake
ml load PrgEnv-gnu/8.3.3
ml load cray-mpich/8.1.25

# necessary to use CUDA-Aware MPI and run a job
export CRAY_ACCEL_TARGET=nvidia80

# optimize CUDA compilation for A100
export AMREX_CUDA_ARCH=8.0

export CXXFLAGS="-march=znver3"
export CFLAGS="-march=znver3"

# compiler environment hints
export CC=cc
export CXX=CC
export FC=ftn
export CUDACXX=$(which nvcc)
export CUDAHOSTCXX=CC

cmake -S . -B cray_mpich -DWarpX_COMPUTE=CUDA
cmake --build cray_mpich -j 16
