#!/bin/bash
##################################################################
#        GPU -> GPU NON-BLOCKING COLLECTIVES - 4 NODES
##################################################################
#SBATCH --job-name=osumb_non_blocking
#SBATCH --account=nintern_g
#SBATCH --time=1:30:00
#SBATCH --qos=regular
#SBATCH --exclusive
#SBATCH --constraint=gpu
#SBATCH --nodes=4
#SBATCH --gpus-per-node=4
#SBATCH --gpu-bind=none
#SBATCH --array=1-5

# ------- TODO: change the output to the MPI implementation being used
#SBATCH --output="../outputs/gpu_gpu/GNU/Cray_MPICH/non_blocking_collectives/4N-BC-%A-%a-%j.txt"
###SBATCH --output="../outputs/gpu_gpu/GNU/Upstream_MPICH/non_blocking_collectives/4N-BC-%A-%a-%j.txt"
###SBATCH --output="../outputs/gpu_gpu/GNU/OpenMPI/non_blocking_collectives/4N-BC-%A-%a-%j.txt"

#---------------------------------------------------
# Set environment variables
#---------------------------------------------------
export CRAY_ACCEL_TARGET=nvidia80
export MPICH_GPU_SUPPORT_ENABLED=1
export MPICH_OFI_NIC_POLICY=GPU
export SRUN_CPUS_PER_TASK=32
export CUDA_VISIBLE_DEVICES=3,2,1,0
export GPU

#---------------------------------------------------
# Set the project root for the osu microbenchmarks
#---------------------------------------------------
cd ../../
osumb_root=$(pwd)

#---------------------------------------------------
# Specify which benchmark executables we want to run
#---------------------------------------------------
# non-blocking collectives directory
non_blocking_collectives=$osumb_root/c/mpi/collective/non_blocking

# benchmark executables
osu_igather=$non_blocking_collectives/osu_igather
osu_iallgather=$non_blocking_collectives/osu_iallgather
osu_ireduce=$non_blocking_collectives/osu_ireduce
osu_iallreduce=$non_blocking_collectives/osu_iallreduce
osu_ibcast=$non_blocking_collectives/osu_ibcast
osu_ialltoall=$non_blocking_collectives/osu_ialltoall

#---------------------------------------------------
# Run configuration
#---------------------------------------------------
nodes=4
gpus_per_node=4
nics_per_node=4

#---------------------------------------------------
# Compute the total number of tasks 
# to run on the full system (n_any),
# and the next smaller odd number (n_odd)
#---------------------------------------------------
N_any=$(( SLURM_JOB_NUM_NODES     ))
n_any=$(( SLURM_JOB_NUM_NODES * nics_per_node ))
N_odd=$N_any
n_odd=$n_any
if [ $(( n_any % 2 )) -eq 0 ]; then
  n_odd=$(( n_any - 1 ))
  if [ $nics_per_node -eq 1 ]; then
    N_odd=$n_odd
  fi
fi

#---------------------------------------------------
# Set variables for flags passed in when we call $exe
#---------------------------------------------------
max_message=16777216
mem_limit=$((max_message * nics_per_node * nodes))
osumb_flags="--accelerator=cuda --message-size=$max_message --mem-limit=$mem_limit --type=mpi_float --validation -x 20 D D"
# TODO: leave $srun_flags blank unless using Open MPI
srun_flags=""
# srun_flags="--mpi=pmix_v4"

#---------------------------------------------------
# Functions for printing output
#---------------------------------------------------
HHLINE="======================================================================"
HLINE="----------------------------------------"
print_header() {
  local test_num=$1
  echo $HHLINE
  echo "                          TEST #$test_num"
  echo $HHLINE
}

print_config() {
  local ntasks_per_node=$1
  local benchmark=$2
  echo $HLINE
  echo " Benchmark:           $benchmark"
  echo " Flags                $osumb_flags"
  echo " srun Flags           $srun_flags" 
  echo " nodes:               $nodes"
  echo " ntasks_per_node:     $ntasks_per_node"
  echo " gpus_per_node:       $gpus_per_node"
  echo " Node IDs:            $SLURM_JOB_NODELIST"
  echo " SLURM Array Task ID: $SLURM_ARRAY_TASK_ID" 
  echo $HLINE
}

#---------------------------------------------------
# Run benchmarks
#---------------------------------------------------
wait
ml
for i in {1..1}; do # adjust to run more iterations per job
  print_header $i

  print_config $nics_per_node "osu_igather"
  srun -N $nodes --ntasks-per-node=${nics_per_node} $srun_flags \
      $osu_igather $osumb_flags
  echo ; echo
  wait

  print_config $nics_per_node "osu_iallgather"
  srun -N $nodes --ntasks-per-node=${nics_per_node} $srun_flags \
      $osu_iallgather $osumb_flags
  echo ; echo
  wait

  print_config $nics_per_node "osu_ireduce"
  srun -N $nodes --ntasks-per-node=${nics_per_node} $srun_flags \
      $osu_ireduce $osumb_flags
  echo ; echo
  wait

  print_config $nics_per_node "osu_iallreduce"
  srun -N $nodes --ntasks-per-node=${nics_per_node} $srun_flags \
      $osu_iallreduce $osumb_flags
  echo ; echo
  wait

  print_config $nics_per_node "osu_ibcast"
  srun -N $nodes --ntasks-per-node=${nics_per_node} $srun_flags \
      $osu_ibcast $osumb_flags
  echo ; echo
  wait

  print_config $nics_per_node "osu_ialltoall"
  srun -N $nodes --ntasks-per-node=${nics_per_node} $srun_flags \
    $osu_ialltoall $osumb_flags
  echo ; echo
  wait
done
wait