#!/bin/bash
##################################################################
#           GPU -> GPU POINT-TO-POINT    - 2 NODES
##################################################################
#-------------------------------------------------------------------------
#SBATCH --job-name=osumb_pt2pt
#SBATCH --account=nintern_g
#SBATCH --time=0:30:00
#SBATCH --qos=regular
#SBATCH --exclusive
#SBATCH --constraint=gpu
#SBATCH --gpu-bind=none
#SBATCH --nodes=2
#SBATCH --gpus-per-node=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=128
#SBATCH --array=1-5

# ------- TODO: change the output to the MPI implementation being used
#SBATCH --output="../outputs/gpu_gpu/GNU/Cray_MPICH/pt2pt/PT2PT-%A-%a-%j.txt"
###SBATCH --output="../outputs/gpu_gpu/GNU/Upstream_MPICH/pt2pt/PT2PT-%A-%a-%j.txt"
###SBATCH --output="../outputs/gpu_gpu/GNU/OpenMPI/pt2pt/PT2PT-%A-%a-%j.txt"
#-------------------------------------------------------------------------
export CRAY_ACCEL_TARGET=nvidia80
export MPICH_GPU_SUPPORT_ENABLED=1
export MPICH_OFI_NIC_POLICY=GPU
export SRUN_CPUS_PER_TASK=32
export CUDA_VISIBLE_DEVICES=3,2,1,0
export GPU
#-------------------------------------------------------------------------
cd ../../
osumb_root=$(pwd)

pt2pt_standard=$osumb_root/c/mpi/pt2pt/standard
osu_latency=$pt2pt_standard/osu_latency
osu_bw=$pt2pt_standard/osu_bw
#-------------------------------------------------------------------------
nodes=2
gpus_per_node=1
nics_per_node=4
#-------------------------------------------------------------------------
max_message=16777216
mem_limit=$((max_message * nics_per_node * nodes))
osumb_flags="--accelerator=cuda --message-size=16777216 --type=mpi_float --validation -x 20 D D"
# srun_flags="--mpi=pmix_v4" # TODO: ENABLE THIS ONE FOR OPEN MPI
srun_flags=""
#-------------------------------------------------------------------------
HHLINE="======================================================================"
HLINE="----------------------------------------"
print_header() {
  local test_num=$1
  echo $HHLINE
  echo "                          TEST #$test_num"
  echo $HHLINE
}

print_config() {
  local ntasks_per_node=$1
  local benchmark=$2
  echo $HLINE
  echo " Benchmark:           $benchmark"
  echo " Flags                $osumb_flags"
  echo " srun Flags           $srun_flags" 
  echo " nodes:               $nodes"
  echo " ntasks_per_node:     $ntasks_per_node"
  echo " gpus_per_node:       $gpus_per_node"
  echo " Node IDs:            $SLURM_JOB_NODELIST"
  echo " SLURM Array Task ID: $SLURM_ARRAY_TASK_ID" 
  echo $HLINE
}
#-------------------------------------------------------------------------
wait
ml
for i in {1..1}; do
  print_header $i

  print_config 1 "osu_latency"
  srun --ntasks-per-node=1 $srun_flags $osu_latency $osumb_flags
  wait
  echo ; echo

  print_config 1 "osu_bw"
  srun --ntasks-per-node=1 $srun_flags $osu_bw $osumb_flags
  wait
  echo ; echo
done
wait