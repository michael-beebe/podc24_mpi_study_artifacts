#!/bin/bash
##################################################################
#        GPU -> GPU BLOCKING COLLECTIVES - 8 NODES
##################################################################
#SBATCH --job-name=osumb_blocking
#SBATCH --account=nintern_g
#SBATCH --time=3:00:00
#SBATCH --qos=regular
#SBATCH --exclusive
#SBATCH --constraint=gpu
#SBATCH --nodes=8
#SBATCH --gpus-per-node=4
#SBATCH --gpu-bind=none
#SBATCH --array=1-5

# ------- TODO: change the output to the MPI implementation being used
#SBATCH --output="../outputs/gpu_gpu/GNU/Cray_MPICH/blocking_collectives/8N-BC-%A-%a-%j.txt"
###SBATCH --output="../outputs/gpu_gpu/GNU/Upstream_MPICH/blocking_collectives/8N-BC-%A-%a-%j.txt"
###SBATCH --output="../outputs/gpu_gpu/GNU/OpenMPI/blocking_collectives/8N-BC-%A-%a-%j.txt"

#---------------------------------------------------
# Set environment variables
#---------------------------------------------------
export CRAY_ACCEL_TARGET=nvidia80
export MPICH_GPU_SUPPORT_ENABLED=1
export MPICH_OFI_NIC_POLICY=GPU
export SRUN_CPUS_PER_TASK=32
export CUDA_VISIBLE_DEVICES=3,2,1,0
export GPU

#---------------------------------------------------
# Set the project root for the osu microbenchmarks
#---------------------------------------------------
cd ../../
osumb_root=$(pwd)

#---------------------------------------------------
# Specify which benchmark executables we want to run
#---------------------------------------------------
# blocking collectives directory
blocking_collectives=$osumb_root/c/mpi/collective/blocking

# benchmark executables
osu_gather=$blocking_collectives/osu_gather
osu_allgather=$blocking_collectives/osu_allgather
osu_reduce=$blocking_collectives/osu_reduce
osu_allreduce=$blocking_collectives/osu_allreduce
osu_bcast=$blocking_collectives/osu_bcast
osu_alltoall=$blocking_collectives/osu_alltoall

#---------------------------------------------------
# Run configuration
#---------------------------------------------------
nodes=8
gpus_per_node=4
nics_per_node=4

#---------------------------------------------------
# Compute the total number of tasks 
# to run on the full system (n_any),
# and the next smaller odd number (n_odd)
#---------------------------------------------------
N_any=$(( SLURM_JOB_NUM_NODES     ))
n_any=$(( SLURM_JOB_NUM_NODES * nics_per_node ))
N_odd=$N_any
n_odd=$n_any
if [ $(( n_any % 2 )) -eq 0 ]; then
  n_odd=$(( n_any - 1 ))
  if [ $nics_per_node -eq 1 ]; then
    N_odd=$n_odd
  fi
fi

#---------------------------------------------------
# Set variables for flags passed in when we call $exe
#---------------------------------------------------
max_message=16777216
mem_limit=$((max_message * nics_per_node * nodes))
osumb_flags="--accelerator=cuda --message-size=$max_message --mem-limit=$mem_limit --type=mpi_float --validation -x 20 D D"
# TODO: leave $srun_flags blank unless using Open MPI
srun_flags=""
# srun_flags="--mpi=pmix_v4"

#---------------------------------------------------
# Functions for printing output
#---------------------------------------------------
HHLINE="======================================================================"
HLINE="----------------------------------------"
print_header() {
  local test_num=$1
  echo $HHLINE
  echo "                          TEST #$test_num"
  echo $HHLINE
}

print_config() {
  local ntasks_per_node=$1
  local benchmark=$2
  echo $HLINE
  echo " Benchmark:           $benchmark"
  echo " Flags                $osumb_flags"
  echo " srun Flags           $srun_flags" 
  echo " nodes:               $nodes"
  echo " ntasks_per_node:     $ntasks_per_node"
  echo " gpus_per_node:       $gpus_per_node"
  echo " Node IDs:            $SLURM_JOB_NODELIST"
  echo " SLURM Array Task ID: $SLURM_ARRAY_TASK_ID" 
  echo $HLINE
}

#---------------------------------------------------
# Run benchmarks
#---------------------------------------------------
wait
ml
for i in {1..1}; do # adjust to run more iterations per job
  print_header $i

  print_config $nics_per_node "osu_gather"
  srun -N $nodes --ntasks-per-node=${nics_per_node} $srun_flags \
      $osu_gather $osumb_flags
  echo ; echo
  wait

  print_config $nics_per_node "osu_allgather"
  srun -N $nodes --ntasks-per-node=${nics_per_node} $srun_flags \
      $osu_allgather $osumb_flags
  echo ; echo
  wait

  print_config $nics_per_node "osu_reduce"
  srun -N $nodes --ntasks-per-node=${nics_per_node} $srun_flags \
      $osu_reduce $osumb_flags
  echo ; echo
  wait

  print_config $nics_per_node "osu_allreduce"
  srun -N $nodes --ntasks-per-node=${nics_per_node} $srun_flags \
      $osu_allreduce $osumb_flags
  echo ; echo
  wait

  print_config $nics_per_node "osu_bcast"
  srun -N $nodes --ntasks-per-node=${nics_per_node} $srun_flags \
      $osu_bcast $osumb_flags
  echo ; echo
  wait

  print_config $nics_per_node "osu_alltoall"
  srun -N $nodes --ntasks-per-node=${nics_per_node} $srun_flags \
    $osu_alltoall $osumb_flags
  echo ; echo
  wait
done
wait